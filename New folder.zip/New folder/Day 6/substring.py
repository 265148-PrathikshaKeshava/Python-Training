import span
 
str1 = input("enter the string\n")
substr = input("enter the sub_string\n")
print(span.getSpan(str1, substr))