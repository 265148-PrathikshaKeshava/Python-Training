from setuptools import setup

setup(name='ppackage',
version='0.1',
description='Testing installation of Package',
url='#',
author='purushotham',
author_email='purushotham@mindfullearning.in',
license='MIT',
packages=['ppackage'],
zip_safe=False)