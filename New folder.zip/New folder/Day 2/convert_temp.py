print("Enter the ur choice")
print("1. Cel to fer")
print("2. fer to cel")
ch = int(input("choice"))


if ch == 1:
    temp = float(input("Enter temp in cel"))
    
elif ch == 2:
    temp = float(input("Enter temp in fer"))